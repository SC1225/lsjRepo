package com.kh.main;

import java.util.Random;

import com.kh.slot.Slot;

public class Main {

	public static void main(String[] args) {
		Slot slot = new Slot();
		slot.RandomSlot();
		

	}

}
