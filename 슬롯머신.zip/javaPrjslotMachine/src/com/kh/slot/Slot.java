package com.kh.slot;
import java.util.Random;

public class Slot {
	
	Random random = new Random();
	
	int a,b,c;
	int i = 0;
	
	public void RandomSlot() {
		while(true) {
			i++;
			a = (random.nextInt(9)+1);
			b = (random.nextInt(9)+1);
			c = (random.nextInt(9)+1);
			System.out.println(i+"번째 슬롯"+" ["+a+"]"+"["+b+"]"+"["+c+"]");
			if((a==b)&&(b==c)) {
				System.out.println("----당첨!!----"); break;
			}
		}
	}

}
